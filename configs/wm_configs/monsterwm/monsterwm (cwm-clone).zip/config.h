// Add Config.h
#ifndef CONFIG_H
#define CONFIG_H


// Modifiers
#define MOD1            	Mod1Mask    		// ALT
#define MOD4            	Mod4Mask    		// Super
#define CONTROL         	ControlMask 		// Control
#define SHIFT           	ShiftMask   		// Shift

// Appearance Related Settings
#define FOCUS           	"#5e2b25"	 		// Focused border color
#define UNFOCUS         	"#0f0f0f" 			// Normal border color
#define BORDER_WIDTH    	4         			// Border width
#define SHOW_PANEL      	False      			// Show panel by default
#define TOP_PANEL       	True      			// False means panel is on bottom
#define PANEL_HEIGHT    	0        			// 0 for no space for panel, thus no panel
#define USELESSGAP      	10					// Useless Gap

// General Settings
#define MASTER_SIZE     	0.50
#define DEFAULT_MODE    	FLOAT	      		// Initial layout: TILE MONOCLE BSTACK GRID FLOAT
#define ATTACH_ASIDE    	True      			// False means new window is master
#define FOLLOW_WINDOW   	False     			// Follow the window when moved to a different desktop
#define FOLLOW_MOUSE    	False     			// Focus the window the mouse just entered
#define CLICK_TO_FOCUS  	True      			// Focus an unfocused window when clicked
#define FOCUS_BUTTON    	Button1   			// Mouse button to be used along with CLICK_TO_FOCUS
#define MINWSZ          	300        			// Minimum window size in pixels
#define DEFAULT_DESKTOP 	0         			// Desktop to focus initially
#define DESKTOPS        	4         			// Number of desktops


// 0 is Fist Desktop
// - Means current desktop
static const AppRule rules[] = {
    //  Class     		  Desktop    Follow    Float
    { "Gcolor2",           -1,      True,     True },
//  { "feh",               -1,      True,     True },

};


// Command Helper + Definitions
#define SHCMD(cmd) {.com = (const char*[]){"/bin/sh", "-c", cmd, NULL}}
#define DESKTOPCHANGE(K,N) \
    {  MOD1,             K,              change_desktop, {.i = N}}, \
    {  MOD1|ShiftMask,   K,              client_to_desktop, {.i = N}},


// Keybinds
static Key keys[] = {
    // Modifier          Key            Function           Args
    {  0,		         XK_F4,         killclient,        {NULL}},
    {  MOD1,             XK_Tab,        next_win,          {NULL}},
    {  MOD1|CONTROL,     XK_Right,      rotate,            {.i = +1}},
    {  MOD1|CONTROL,     XK_Left,       rotate,            {.i = -1}},
    {  MOD1|SHIFT,       XK_q,          quit,              {.i = 0}},

    // Move / Resize Longstep
    {  MOD4,             XK_Down,       moveresize,        {.v = (int []){   0,  8,   0,   0 }}}, 		// move down
    {  MOD4,             XK_Up,         moveresize,        {.v = (int []){   0, -8,   0,   0 }}}, 		// move up
    {  MOD4,             XK_Right,      moveresize,        {.v = (int []){  8,   0,   0,   0 }}}, 		// move right
    {  MOD4,             XK_Left,       moveresize,        {.v = (int []){ -8,   0,   0,   0 }}}, 		// move left
    {  MOD4|SHIFT,	     XK_Down,       moveresize,        {.v = (int []){   0,   0,   0,  8 }}}, 		// height grow
    {  MOD4|SHIFT,  	 XK_Up,         moveresize,        {.v = (int []){   0,   0,   0, -8 }}}, 		// height shrink
    {  MOD4|SHIFT, 	     XK_Right,      moveresize,        {.v = (int []){   0,   0,  8,   0 }}}, 		// width grow
    {  MOD4|SHIFT, 	     XK_Left,       moveresize,        {.v = (int []){   0,   0, -8,   0 }}}, 		// width shrink

	// Desktop Switching
       DESKTOPCHANGE(    XK_1,                             0)
       DESKTOPCHANGE(    XK_2,                             1)
       DESKTOPCHANGE(    XK_3,                             2)
       DESKTOPCHANGE(    XK_4,                             3)
};


// Mousebinds
static Button buttons[] = {
    {  MOD1,    Button1,     mousemotion,   {.i = MOVE}},
    {  MOD1,    Button3,     mousemotion,   {.i = RESIZE}},
};
#endif
