# Gruvbox Sassy CSS Colors

`.scss` files full of color variables from the [Morhetz Gruvbox Theme](https://github.com/morhetz/gruvbox)

It is broken up by Dark Mode, Light Mode, and all the Modes!
