# SOME DESCRIPTIVE TITLE.
# Copyright (C) YEAR THE PACKAGE'S COPYRIGHT HOLDER
# This file is distributed under the same license as the PACKAGE package.
# FIRST AUTHOR <EMAIL@ADDRESS>, YEAR.
#
#, fuzzy
msgid ""
msgstr ""
"Project-Id-Version: PACKAGE VERSION\n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: 2017-10-15 00:02+0500\n"
"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\n"
"Last-Translator: FULL NAME <EMAIL@ADDRESS>\n"
"Language-Team: LANGUAGE <LL@li.org>\n"
"Language: \n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=CHARSET\n"
"Content-Transfer-Encoding: 8bit\n"

#: src/connection.c:177 src/connection.c:274
msgid "write failed"
msgstr ""

#: src/connection.c:180 src/connection.c:277
#, c-format
msgid "Unable to write to file %s: %s!"
msgstr ""

#: src/connection.c:201 src/connection.c:258
msgid "connection timed out"
msgstr ""

#: src/connection.c:212 src/connection.c:296
#, c-format
msgid "download for this connection completed%s : %ld received"
msgstr ""

#: src/connection.c:249
msgid "Server Closed Connection Prematurely!"
msgstr ""

#: src/connection.c:346
msgid "Idle"
msgstr ""

#: src/connection.c:349
msgid "Connecting"
msgstr ""

#: src/connection.c:352
msgid "Logging in"
msgstr ""

#: src/connection.c:355
msgid "Downloading"
msgstr ""

#: src/connection.c:358
msgid "Completed"
msgstr ""

#: src/connection.c:361
msgid "Login Denied"
msgstr ""

#: src/connection.c:364
msgid "Connect Refused"
msgstr ""

#: src/connection.c:367
msgid "Remote Fatal"
msgstr ""

#: src/connection.c:370
msgid "Local Fatal"
msgstr ""

#: src/connection.c:373
msgid "Timed Out"
msgstr ""

#: src/connection.c:375
msgid "Max attempts reached"
msgstr ""

#: src/connection.c:378
msgid "Unkown Status!"
msgstr ""

#: src/connection.c:469 src/misc.c:471
msgid "Error: unsupported protocol"
msgstr ""

#: src/connection.c:493
#, c-format
msgid "The server returned location is wrong: %s!"
msgstr ""

#: src/connection.c:502
#, c-format
msgid "Redirected to => %s"
msgstr ""

#: src/debug.c:60 src/download.c:826
#, c-format
msgid "unable to delete the file %s. Reason-: %s"
msgstr ""

#: src/download.c:133 src/download.c:158 src/download.c:2050
#: src/download.c:2068
#, c-format
msgid "Unable to open file %s: %s!"
msgstr ""

#: src/download.c:301
msgid "Warning! Unable to create logfile!"
msgstr ""

#: src/download.c:320 src/download.c:331 src/download.c:473 src/download.c:499
#: src/download.c:534 src/download.c:579 src/download.c:600 src/download.c:626
#: src/download.c:671 src/download.c:692 src/download.c:1276
#: src/download.c:1448 src/download.c:1536 src/download.c:1614
#: src/download.c:1667 src/download.c:1722 src/download.c:1747
#: src/download.c:1773 src/download.c:1823 src/download.c:1878
#: src/download.c:1903
msgid "Error: Not enough system resources"
msgstr ""

#: src/download.c:335
msgid "Error: Unsupported Protocol was specified"
msgstr ""

#: src/download.c:339
msgid "All threads created"
msgstr ""

#: src/download.c:459 src/download.c:1378
msgid "The file was not found in all the connections!"
msgstr ""

#: src/download.c:465 src/download.c:491 src/download.c:575 src/download.c:596
#: src/download.c:667 src/download.c:688 src/download.c:1443
#: src/download.c:1663 src/download.c:1718 src/download.c:1743
#: src/download.c:1874 src/download.c:1899
msgid "Relaunching download"
msgstr ""

#: src/download.c:485 src/download.c:1469
msgid "Failed to change to the working directory on all the connections!"
msgstr ""

#: src/download.c:511 src/download.c:1592
#, c-format
msgid "Connection %d, had a local fatal error: %s .Aborting download. "
msgstr ""

#: src/download.c:526 src/download.c:1607
msgid "All logins rejected! Retrying connection"
msgstr ""

#: src/download.c:618 src/download.c:1765
msgid "All connections attempts have been  rejected! Retrying connection"
msgstr ""

#: src/download.c:1416 src/download.c:1508
msgid "Trying additional paths available on this server"
msgstr ""

#: src/download.c:1556
msgid "The server(s) do not support  REST on all the connections!"
msgstr ""

#: src/download.c:1579
msgid ""
"This server does not support resuming downloads, so will switch to another "
"server"
msgstr ""

#: src/download.c:1645
msgid ""
"This server has rejected the login attempt, so will switch to another server"
msgstr ""

#: src/download.c:1803
msgid ""
"This server has rejected the connection attempt, so will switch to another "
"server"
msgstr ""

#: src/ftp.c:127
#, c-format
msgid "Error checking for FTP data: %s"
msgstr ""

#: src/ftp.c:144
#, c-format
msgid "Error receiving FTP data: %s"
msgstr ""

#: src/ftp.c:168
#, c-format
msgid "Sending:  %s"
msgstr ""

#: src/ftp.c:173
#, c-format
msgid "Error sending FTP data: %s"
msgstr ""

#: src/ftp.c:217
#, c-format
msgid "Received: %s"
msgstr ""

#: src/ftp.c:355
#, c-format
msgid "FTP PASV Header = %s"
msgstr ""

#. Unknown error code.
#: src/ftp.c:775
#, c-format
msgid "Unknown code %d retuned during FTP login"
msgstr ""

#: src/ftp.c:827 src/ftp.c:847 src/http.c:564 src/http.c:579 src/http-retr.c:69
#: src/http-retr.c:84
#, c-format
msgid "Connecting to %s"
msgstr ""

#: src/ftp.c:838 src/ftp.c:856
#, c-format
msgid "Error while connecting to %s"
msgstr ""

#: src/ftp.c:843 src/ftp.c:860
#, c-format
msgid "Connected to %s"
msgstr ""

#: src/ftp.c:888 src/ftp.c:897
#, c-format
msgid "Logging in as user %s with password %s"
msgstr ""

#: src/ftp.c:911
msgid "Logged in successfully"
msgstr ""

#: src/ftp.c:931
#, c-format
msgid "CWD failed to change to directory '%s'"
msgstr ""

#: src/ftp.c:940
msgid "CWD not needed"
msgstr ""

#: src/ftp.c:947
msgid "REST failed"
msgstr ""

#: src/ftp.c:952
msgid "REST ok"
msgstr ""

#: src/ftp.c:1043
msgid "FTP LIST failed: File not found or access not permitted."
msgstr ""

#: src/ftp.c:1073
#, c-format
msgid "Error receiving FTP transfer data: %s"
msgstr ""

#: src/ftp.c:1078
#, c-format
msgid "String received after the LIST command = %s"
msgstr ""

#: src/ftp.c:1094
msgid ""
"Unable to parse the line the FTP server returned:please report URL to "
"prozilla@genesys.ro "
msgstr ""

#: src/ftp.c:1129
msgid "Server doesn't seem to support PASV"
msgstr ""

#: src/ftp.c:1205
#, c-format
msgid "Retrying attempt %d in %d seconds"
msgstr ""

#: src/ftp.c:1224 src/http.c:736
msgid "Successfully got info"
msgstr ""

#: src/ftp.c:1232 src/http.c:748
msgid "File not found!"
msgstr ""

#: src/ftp.c:1251 src/ftp-retr.c:319 src/http.c:767 src/http-retr.c:335
#, c-format
msgid "I have tried %d attempt(s) and have failed, aborting"
msgstr ""

#: src/ftp-retr.c:125
#, c-format
msgid "Logging in as user %s with password %s."
msgstr ""

#: src/ftp-retr.c:165
#, c-format
msgid "CWD failed to change to directory '%s'."
msgstr ""

#: src/ftp-retr.c:171
msgid "CWD ok."
msgstr ""

#: src/ftp-retr.c:175
msgid "CWD not needed."
msgstr ""

#: src/ftp-retr.c:196
msgid ""
"I have a bug in my  code!!, check remote_starpos and resume_support values"
msgstr ""

#: src/ftp-retr.c:206
msgid "RETR failed"
msgstr ""

#: src/ftp-retr.c:259
#, c-format
msgid "Retrying..Attempt %d in %d seconds"
msgstr ""

#: src/ftp-retr.c:271 src/http-retr.c:288
msgid "Error while attemting to process download file "
msgstr ""

#: src/ftp-retr.c:302 src/http-retr.c:315
msgid "Successfully got download"
msgstr ""

#: src/ftp-retr.c:308
msgid "Error occured in connection..."
msgstr ""

#: src/http.c:378
msgid "Failed writing HTTP request"
msgstr ""

#: src/http.c:399
#, c-format
msgid "Header = %s"
msgstr ""

#: src/http.c:403
msgid "End of file while parsing headers"
msgstr ""

#: src/http.c:414
msgid "Read error in headers"
msgstr ""

#. Store the descriptive response.
#. Malformed request.
#: src/http.c:440
msgid "UNKNOWN"
msgstr ""

#: src/http.c:442
msgid "(no description)"
msgstr ""

#: src/http.c:573 src/http.c:585 src/http.c:803 src/http-retr.c:77
#: src/http-retr.c:91 src/http-retr.c:398
#, c-format
msgid "Error connecting to %s"
msgstr ""

#: src/http.c:613 src/http.c:830 src/http-retr.c:119 src/http-retr.c:425
#, c-format
msgid "Authenticating as user %s password %s"
msgstr ""

#: src/http.c:614 src/http.c:831 src/http-retr.c:120 src/http-retr.c:426
#, c-format
msgid "Authentification string=%s"
msgstr ""

#: src/http.c:684 src/http-retr.c:199 src/http-retr.c:481
msgid "Sending HTTP request"
msgstr ""

#: src/http.c:719 src/http-retr.c:276
#, c-format
msgid "Retrying...Attempt %d in %d seconds"
msgstr ""

#: src/http-retr.c:308
msgid "Will be handled in main "
msgstr ""

#: src/logfile.c:49
#, c-format
msgid "Error opening file %s for writing: %s"
msgstr ""

#: src/logfile.c:65 src/logfile.c:75 src/logfile.c:97 src/logfile.c:110
#: src/logfile.c:122 src/logfile.c:135
#, c-format
msgid "Error writing to file %s: %s"
msgstr ""

#: src/logfile.c:188
msgid "logfile doesn't exist"
msgstr ""

#: src/logfile.c:221
#, c-format
msgid "Error opening file %s for reading: %s"
msgstr ""

#: src/logfile.c:259 src/logfile.c:274 src/logfile.c:290 src/logfile.c:305
#, c-format
msgid "Error reading from file %s: %s"
msgstr ""

#: src/misc.c:48
#, c-format
msgid "Failed to malloc() %lu bytes."
msgstr ""

#: src/misc.c:63
#, c-format
msgid "Failed to realloc() %lu bytes."
msgstr ""

#: src/misc.c:85
msgid "Not enough memory to continue: strdup() failed."
msgstr ""

#: src/misc.c:304
msgid "Warning: Unable to delay"
msgstr ""

#: src/misc.c:326
msgid "Unable to lookup hostname"
msgstr ""

#: src/misc.c:328
msgid "Unable to create socket"
msgstr ""

#: src/misc.c:330
msgid "Error occured while connecting"
msgstr ""

#: src/misc.c:332 src/misc.c:386
msgid "The connection attempt was refused"
msgstr ""

#: src/misc.c:334
msgid "Error while accepting the connection"
msgstr ""

#: src/misc.c:336
msgid "Error while Binding socket"
msgstr ""

#: src/misc.c:338
msgid "Error while listening"
msgstr ""

#: src/misc.c:340
msgid "The connection was reset/closed by the peer"
msgstr ""

#: src/misc.c:342
msgid "The URL Protocol was unknown"
msgstr ""

#: src/misc.c:344
msgid "The port specified in the URL is not valid!"
msgstr ""

#: src/misc.c:346
msgid "The Hostname specified in the URL is not valid!"
msgstr ""

#: src/misc.c:348
msgid "The Pattern specified in the URL does not look valid!"
msgstr ""

#: src/misc.c:350
msgid "End of file reached in HTTP connection"
msgstr ""

#: src/misc.c:352
msgid "Error occured in HTTP data transfer"
msgstr ""

#: src/misc.c:354
msgid "Authentification is required to access this resource"
msgstr ""

#: src/misc.c:356
msgid "Failed to Authenticate with host!"
msgstr ""

#: src/misc.c:358
msgid "The URL was not found on the host!"
msgstr ""

#: src/misc.c:360
msgid "The host disallowed the login attempt"
msgstr ""

#: src/misc.c:362
msgid "The PORT request was rejected by the server"
msgstr ""

#: src/misc.c:364
msgid "The object file/dir was not found on the host!"
msgstr ""

#: src/misc.c:366
msgid "The TYPE specified in not known by the FTP server!"
msgstr ""

#: src/misc.c:368
msgid "The command is not known by the FTP server!"
msgstr ""

#: src/misc.c:370
msgid "The SIZE command failed"
msgstr ""

#: src/misc.c:372
msgid "Error occured in FTP data transfer"
msgstr ""

#: src/misc.c:374
msgid "The REST command failed"
msgstr ""

#: src/misc.c:376
msgid "The peer did not allow access"
msgstr ""

#: src/misc.c:378 src/misc.c:380
msgid "The host rejected the password"
msgstr ""

#: src/misc.c:382
msgid "The PASV (passive mode) was not supported the host"
msgstr ""

#: src/misc.c:384
msgid "The host does not support PASV (passive mode) transfers"
msgstr ""

#: src/misc.c:388
msgid "Failed to (CWD)change to the directory"
msgstr ""

#: src/misc.c:392
msgid ""
"The host said the requested service was unavailable and closed the control "
"connection"
msgstr ""

#: src/misc.c:394
msgid "getsockname failed!"
msgstr ""

#: src/misc.c:399 src/misc.c:409
msgid ""
"The server, while acting as a gateway or proxy, received an invalid response "
"from the upstream server it accessed in attempting to fulfill the request"
msgstr ""

#: src/misc.c:404
msgid ""
"The server is currently unable to handle the request due to a temporary "
"overloading or maintenance of the server."
msgstr ""

#: src/misc.c:414
msgid ""
"The server encountered an unexpected condition which prevented it from "
"fulfilling the request."
msgstr ""

#: src/misc.c:419
msgid ""
"The server does not support the functionality required to fulfill the "
"request."
msgstr ""

#: src/misc.c:422
msgid "Error while opening file"
msgstr ""

#: src/misc.c:424
msgid "Error while writing to file"
msgstr ""

#: src/misc.c:427
msgid "The Download was aborted"
msgstr ""

#: src/misc.c:429
msgid "The Download encountered a local fatal error"
msgstr ""

#: src/misc.c:431
msgid "Error: Resuming this connection is not possible"
msgstr ""

#: src/misc.c:433
msgid "Error while reading data from socket"
msgstr ""

#: src/misc.c:435
msgid "Error while writing data to socket"
msgstr ""

#: src/misc.c:437
msgid "Error while Proxying"
msgstr ""

#: src/misc.c:439
msgid "The location is a directory"
msgstr ""

#: src/misc.c:442
msgid "Unknown/Unsupported error code"
msgstr ""

#: src/netrc.c:215
#, c-format
msgid "%s:%d: warning: found \"%s\" before any host names\n"
msgstr ""

#: src/netrc.c:243
#, c-format
msgid "%s:%d: warning: unknown token \"%s\"\n"
msgstr ""
