# SOME DESCRIPTIVE TITLE.
# Copyright (C) YEAR THE PACKAGE'S COPYRIGHT HOLDER
# This file is distributed under the same license as the PACKAGE package.
# FIRST AUTHOR <EMAIL@ADDRESS>, YEAR.
#
#, fuzzy
msgid ""
msgstr ""
"Project-Id-Version: PACKAGE VERSION\n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: 2017-10-15 00:02+0500\n"
"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\n"
"Last-Translator: FULL NAME <EMAIL@ADDRESS>\n"
"Language-Team: LANGUAGE <LL@li.org>\n"
"Language: \n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=CHARSET\n"
"Content-Transfer-Encoding: 8bit\n"

#: src/download_win.cpp:522
#, c-format
msgid ""
"A connection(s) of the download %s encountered a unrecoverable remote error, "
"usually the file not being present in the remote server, therefore the "
"download had to be aborted!\n"
msgstr ""

#: src/init.cpp:83
msgid "unable to create the directory to store the config info in"
msgstr ""

#: src/init.cpp:87
msgid "Error while stating the config info directory"
msgstr ""

#: src/main.cpp:178
#, c-format
msgid "%s. Version: %s\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:250
#, c-format
msgid ""
"Error: Invalid arguments for the -k option\n"
"Please type proz --help for help\n"
msgstr ""

#: src/main.cpp:256
#, c-format
msgid ""
"Hey! How can I download anything with 0 (Zero) connections!?\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:267
#, c-format
msgid ""
"Error: Invalid arguments for the -t or --tries option(s)\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:316
#, c-format
msgid ""
"Error: Invalid arguments for the --retry-delay option\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:327
#, c-format
msgid ""
"Error: Invalid arguments for the --timeout option\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:364
#, c-format
msgid ""
"Error: Invalid arguments for the --pt option\n"
"Please type proz --help for help\n"
msgstr ""

#: src/main.cpp:370
#, c-format
msgid ""
"Hey! Does waiting for a server response for Zero(0) seconds make and sense "
"to you!?\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:382 src/main.cpp:401
#, c-format
msgid ""
"Error: Invalid arguments for the --pao option\n"
"Please type proz --help for help\n"
msgstr ""

#: src/main.cpp:388
#, c-format
msgid ""
"Hey you! Will pinging Zero(0) servers at once achive anything for me!?\n"
"Please type proz --help for help\n"
msgstr ""

#: src/main.cpp:407
#, c-format
msgid ""
"Hey! Will requesting Zero(0) servers at oncefrom the ftpearch achive "
"anything!?\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:419
#, c-format
msgid ""
"Error: Invalid arguments for the --max-bps option\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:433
#, c-format
msgid ""
"Error: Invalid arguments for the --min-size option\n"
"Please type proz --help for help\n"
msgstr ""

#.
#. * The call failed  due to a invalid arg
#.
#: src/main.cpp:446
#, c-format
msgid ""
"Error: Invalid arguments for the --ftpsid option\n"
"Please type proz --help for help\n"
msgstr ""

#: src/main.cpp:452
#, c-format
msgid ""
"The available servers are (0) filesearching.com and (1) ftpsearch.elmundo."
"es\n"
"Please type proz --help for help\n"
msgstr ""

#: src/main.cpp:461
#, c-format
msgid "Error: Invalid  option\n"
msgstr ""

#: src/main.cpp:498
#, c-format
msgid "%s does not seem to be a valid URL"
msgstr ""

#: src/prefs.cpp:549
msgid "could not open preferences file for reading"
msgstr ""
