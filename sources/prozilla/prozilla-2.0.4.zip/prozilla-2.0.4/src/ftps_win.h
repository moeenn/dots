
#ifndef ftps_win_h
#define ftps_win_h
#include "prozilla.h"
/*
class ftps_gui {
public:
  ftps_gui();
};
*/
#endif
