// SPDX-License-Identifier: MPL-2.0
// Copyright (c) Yuxuan Shui <yshuiv7@gmail.com>
#include <stdbool.h>

typedef struct session session_t;

bool vsync_init(session_t *ps);
